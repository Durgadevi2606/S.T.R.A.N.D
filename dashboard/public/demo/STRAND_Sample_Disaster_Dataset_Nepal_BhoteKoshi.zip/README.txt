========================================================================
S.T.R.A.N.D - Satellite Tactical Reconnaissance & Autonomous Navigation in Disaster
SAMPLE DISASTER ASSESSMENT & RADAR DATASET
========================================================================

Disaster Theater: Bhote Koshi Basin / Araniko Highway Corridor, Nepal
Satellite Platform: Sentinel-1 IW C-Band SAR
Analysis ID: sar-import-20261007-6a83b3

INCLUDED ARTIFACTS:
------------------------------------------------------------------------
1. flood_inundation_polygons.geojson
   - GeoJSON polygons delineating the 178.56 km² flood inundation extent
   - Extracted from Otsu backscatter thresholding + speckle filtering

2. cut_off_roads.geojson
   - OSM Highway vector segments classified by disaster status:
     * severed (cut off by floodwaters)
     * partially_flooded (traversable with high delay penalty)
     * intact (operational bypass routes)

3. damaged_bridges.geojson
   - Bridge crossings tagged with damage status and flood buffer ratios

4. isolated_settlements_triage.geojson
   - Settlement nodes prioritized by composite urgency index
   - Includes population estimates, medical clinic availability, and cut-off status

5. helicopter_landing_zones_hlz.geojson
   - Flat terrain evacuation landing zones (slope <= 5°, rotor clearance >= 25m)

6. soil_ponding_zones.geojson
   - High-moisture silt saturation and secondary ponding areas

7. sample_sar_radar_imagery.png
   - Pre-calibrated SAR radar test imagery ready to upload directly into the
     S.T.R.A.N.D web dashboard via "UPLOAD SAR RADAR DATA"!

8. disaster_assessment_sitrep.json
   - Full JSON operational metrics and incident commander report

HOW TO USE:
------------------------------------------------------------------------
- Web Dashboard:
  Click "Upload SAR Radar Data" on the top right of http://localhost:5173
  and select `sample_sar_radar_imagery.png` to run real-time SAR ingestion!
- GIS Inspection:
  Open any of the GeoJSON files directly in QGIS, ArcGIS, or drag-and-drop
  them onto https://geojson.io to visualize the vectors.
========================================================================
